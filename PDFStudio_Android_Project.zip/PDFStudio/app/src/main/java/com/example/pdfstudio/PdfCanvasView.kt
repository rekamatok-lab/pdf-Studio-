package com.example.pdfstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

internal data class MarkPoint(val x: Float, val y: Float)
internal data class MarkStroke(
    val points: MutableList<MarkPoint>,
    val color: Int,
    val width: Float,
    val alpha: Int
)
internal data class MarkText(val text: String, val x: Float, val y: Float, val color: Int = Color.BLACK)
internal data class PdfMarkup(
    val strokes: MutableList<MarkStroke> = mutableListOf(),
    val texts: MutableList<MarkText> = mutableListOf()
)

/** A page canvas that keeps every annotation in normalized page coordinates. */
internal class PdfCanvasView(context: Context) : View(context) {
    enum class Tool { PEN, HIGHLIGHTER }

    private var pageBitmap: Bitmap? = null
    private var markup: PdfMarkup = PdfMarkup()
    private var tool = Tool.PEN
    private var currentStroke: MarkStroke? = null
    private val pageRect = RectF()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF252535.toInt() }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        contentDescription = "תצוגת עמוד PDF לעריכה"
    }

    fun setPage(bitmap: Bitmap, pageMarkup: PdfMarkup) {
        pageBitmap = bitmap
        markup = pageMarkup
        currentStroke = null
        invalidate()
    }

    fun setTool(value: Tool) { tool = value }
    fun getMarkup(): PdfMarkup = markup

    fun addText(value: String) {
        if (value.isNotBlank()) {
            markup.texts.add(MarkText(value.trim(), 0.08f, 0.52f))
            invalidate()
        }
    }

    fun undo() {
        if (markup.strokes.isNotEmpty()) markup.strokes.removeAt(markup.strokes.lastIndex)
        else if (markup.texts.isNotEmpty()) markup.texts.removeAt(markup.texts.lastIndex)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFF252535.toInt())
        val bitmap = pageBitmap ?: return
        val scale = min(width.toFloat() / bitmap.width.toFloat(), height.toFloat() / bitmap.height.toFloat())
        val drawW = bitmap.width * scale
        val drawH = bitmap.height * scale
        pageRect.set((width - drawW) / 2f, (height - drawH) / 2f, (width + drawW) / 2f, (height + drawH) / 2f)
        canvas.drawRect(pageRect, bgPaint)
        val save = canvas.save()
        canvas.translate(pageRect.left, pageRect.top)
        canvas.scale(pageRect.width(), pageRect.height())
        canvas.drawBitmap(bitmap, null, RectF(0f, 0f, 1f, 1f), Paint(Paint.FILTER_BITMAP_FLAG))
        drawMarkupNormalized(canvas, markup)
        canvas.restoreToCount(save)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bitmap = pageBitmap ?: return false
        if (pageRect.width() <= 0f || pageRect.height() <= 0f) return false
        val x = ((event.x - pageRect.left) / pageRect.width()).coerceIn(0f, 1f)
        val y = ((event.y - pageRect.top) / pageRect.height()).coerceIn(0f, 1f)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!pageRect.contains(event.x, event.y)) return false
                val highlighter = tool == Tool.HIGHLIGHTER
                currentStroke = MarkStroke(
                    mutableListOf(MarkPoint(x, y)),
                    if (highlighter) 0xFFFFD84D.toInt() else 0xFF2F5EEA.toInt(),
                    if (highlighter) 0.018f else 0.006f,
                    if (highlighter) 92 else 255
                )
                markup.strokes.add(currentStroke!!)
                parent?.requestDisallowInterceptTouchEvent(true)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                currentStroke?.points?.add(MarkPoint(x, y))
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                currentStroke?.points?.add(MarkPoint(x, y))
                currentStroke = null
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
                return true
            }
        }
        return true
    }

    companion object {
        fun renderMarkup(markup: PdfMarkup, width: Int, height: Int): Bitmap {
            val bitmap = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.scale(bitmap.width.toFloat(), bitmap.height.toFloat())
            drawMarkupNormalized(canvas, markup)
            return bitmap
        }

        private fun drawMarkupNormalized(canvas: Canvas, markup: PdfMarkup) {
            for (stroke in markup.strokes) {
                if (stroke.points.isEmpty()) continue
                val path = Path()
                path.moveTo(stroke.points.first().x, stroke.points.first().y)
                for (point in stroke.points.drop(1)) path.lineTo(point.x, point.y)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = stroke.color
                    alpha = stroke.alpha
                    style = Paint.Style.STROKE
                    strokeWidth = stroke.width
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
                canvas.drawPath(path, paint)
            }
            for (item in markup.texts) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = item.color
                    textSize = 0.045f
                    style = Paint.Style.FILL
                    typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
                }
                val lines = item.text.split('\n')
                lines.forEachIndexed { index, line -> canvas.drawText(line, item.x, item.y + index * 0.055f, paint) }
            }
        }
    }
}
