package com.example.pdfstudio

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

internal object Ui {
    const val BG = 0xFF11111B.toInt()
    const val PANEL = 0xFF1B1B29.toInt()
    const val PANEL_2 = 0xFF242438.toInt()
    const val TEXT = 0xFFF6F3FF.toInt()
    const val MUTED = 0xFFB8B2C9.toInt()
    const val ACCENT = 0xFF9A7BFF.toInt()
    const val ACCENT_2 = 0xFF6D57D9.toInt()

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Int, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != null) setStroke(1, strokeColor)
        }

    fun text(context: Context, value: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(context).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_RTL
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }

    fun button(context: Context, value: String, primary: Boolean = false): Button =
        Button(context).apply {
            text = value
            textSize = 14f
            isAllCaps = false
            setTextColor(if (primary) Color.WHITE else TEXT)
            background = rounded(if (primary) ACCENT_2 else PANEL_2, dp(context, 14), if (primary) null else 0xFF393950.toInt())
            minHeight = dp(context, 48)
            minimumHeight = dp(context, 48)
            setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 8))
            stateListAnimator = null
        }

    fun section(context: Context, value: String): TextView = text(context, value, 16f, TEXT, true).apply {
        setPadding(0, dp(context, 12), 0, dp(context, 7))
    }

    fun panel(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(PANEL, dp(context, 20))
        setPadding(dp(context, 16), dp(context, 14), dp(context, 16), dp(context, 14))
    }

    fun horizontal(context: Context, gapDp: Int = 8): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val p = dp(context, gapDp / 2)
        setPadding(p, 0, p, 0)
    }

    fun addGap(parent: LinearLayout, context: Context, heightDp: Int) {
        parent.addView(View(context), LinearLayout.LayoutParams(1, dp(context, heightDp)))
    }
}
