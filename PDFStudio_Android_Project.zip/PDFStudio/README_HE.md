# PDF Studio — פרויקט Android מקורי

אפליקציית Kotlin מקורית ל-Android. אין כאן אתר, WebView או קובץ HTML.

## יכולות בגרסה זו
- פתיחת קובצי PDF דרך בורר הקבצים של Android.
- הצגת עמודים ודפדוף קדימה/אחורה.
- כתיבה וחתימה ביד עם האצבע.
- סימון/הדגשה בצבע צהוב.
- הוספת הערת טקסט לעמוד.
- ביטול הסימון האחרון.
- שמירת עותק PDF חדש, בלי לדרוס את קובץ המקור.

**הערה חשובה:** כלי העריכה מוסיפים שכבת סימונים מעל הדף. הם לא משנים טקסט קיים בתוך ה-PDF ולא מבצעים OCR.

## בניית APK
דרישות: Android Studio עדכני, JDK 17 ו-Android SDK Platform 36.

1. פתח ב-Android Studio את תיקיית `PDFStudio`.
2. המתן ל-Gradle Sync ולהורדת הספריות.
3. בתפריט Build בחר **Build APK(s)**.
4. קובץ ה-debug יופיע בנתיב `app/build/outputs/apk/debug/app-debug.apk`.

אפשר גם להריץ בטרמינל מתוך התיקייה:

```bash
./gradlew assembleDebug
```

ב-Windows:

```bat
gradlew.bat assembleDebug
```

בהרצה הראשונה סקריפט Gradle מוריד את Gradle 8.13 ואת התלויות ממאגרי Google Maven Central. נדרשת גישה לאינטרנט בזמן הבנייה.

## פרטי הפרויקט
- Package: `com.example.pdfstudio`
- Min SDK: 23 (Android 6.0)
- Target SDK: 35
- Kotlin / Android Gradle Plugin
- תצוגה: Android `PdfRenderer`
- כתיבה ושמירת שכבת הסימונים: PDFBox-Android 2.0.27.0
